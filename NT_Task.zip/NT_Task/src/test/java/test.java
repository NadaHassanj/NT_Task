import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class test {
    WebDriver driver;
    @BeforeMethod
    public void setUp() {
        driver = new ChromeDriver();
        driver.get("https://practice.automationtesting.in/");
    }

    @Test
    public void testBookExistsAndAddToBasket() {
        WebElement book = driver.findElement(By.cssSelector("a[href*='thinking-in-html']"));
        Assert.assertTrue(book.isDisplayed(), "Book 'Thinking in HTML' should be displayed");

        WebElement price = driver.findElement(By.className("price"));
        Assert.assertNotNull(price.getText(), "Price for 'Thinking in HTML' should be visible");

        driver.findElement(By.cssSelector("a[href*='thinking-in-html']")).click();
        driver.findElement(By.xpath("//*[@id=\"product-163\"]/div[2]/form/button")).click();
        driver.findElement(By.xpath("//*[@id=\"wpmenucartli\"]/a/i")).click();
        //driver.findElement(By.xpath("//*[@id=\"content\"]/div[1]/a")).click();

        WebElement cartItem = driver.findElement(By.xpath("//*[@id=\"page-34\"]/div/div[1]/form/table/tbody/tr[1]/td[3]/a"));
        Assert.assertTrue(cartItem.isDisplayed(), "Item 'Thinking in HTML' should be in the cart");

        WebElement checkoutButton = driver.findElement(By.xpath("//*[@id=\"page-34\"]/div/div[1]/div/div/div/a"));
        checkoutButton.click();

        WebElement billingForm = driver.findElement(By.xpath("//*[@id=\"customer_details\"]/div[1]/div/h3"));
        Assert.assertTrue(billingForm.isDisplayed(), "Billing Details form should be displayed");
    }
    @AfterMethod
    public void tearDown() {
            driver.quit();
    }
}